package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CheckBalance {
	
	private String accno,accnm;
	private double balance;
	public boolean flag=false;
	 public double getBalance() {
		return balance;
	}
	
	public String getAccnm() {
		return accnm;
	}
	public void setAccno(String uid) {
		this.accno = uid;
	}
	
	public boolean isFlag() {
		return flag;
	}

	public void getBalanceOfUser() {
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select * from accounts where accno=?;");
			pst.setString(1, accno);
			
			
			rs=pst.executeQuery();
			if(rs.next()) {
		     accno=rs.getString("accno");
			accnm=rs.getString("accnm");
		balance=Double.parseDouble(rs.getString("balance"));
		flag=true;
			}
			else {
				flag=false;
			}
			
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}

