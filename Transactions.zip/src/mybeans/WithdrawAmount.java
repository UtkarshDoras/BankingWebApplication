package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class WithdrawAmount {
	private String accno;
	private double amt;
	private boolean withdrawstatus=false;
	
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	

	
	public void withdrawAmt() {
		Connection con;
		PreparedStatement pst;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("insert into acctransactions values(default,?,'withdraw',?,default);");
			pst.setString(1, accno);
			pst.setDouble(2, amt);
			
			pst.executeUpdate();
			withdrawstatus=true;
			
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	
public boolean isWithdrawstatus() {
		return withdrawstatus;
	}

}



