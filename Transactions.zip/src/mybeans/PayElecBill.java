package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PayElecBill {
	private String accno;
	private double amt;
	public boolean paymentstatus=false; 
	
	
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	
	public void onPayment() {
		PreparedStatement pst;
		Connection con;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("update accounts set balance=balance+? where accno=?;");
			pst.setDouble(1, amt);
			pst.setString(2, accno);
		    
			pst.executeUpdate();
			paymentstatus=true;
			
			con.close();
	}
		catch(Exception e) {
			System.out.println(e);
		}
	
	}
	
	public boolean isPaymentstatus() {
		return paymentstatus;
	}
}
