package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ShowProfileDetails {
	private String accno;
	public String joiningdate;
	public String city;
	public String mobile;
	public String emailid;
	public boolean flag=false;
	
	
	
	
	public boolean isFlag() {
		return flag;
	}



	public String getJoiningdate() {
		return joiningdate;
	}



	public String getCity() {
		return city;
	}



	public String getMobile() {
		return mobile;
	}



	public String getEmailid() {
		return emailid;
	}



	public void setAccno(String accno) {
		this.accno = accno;
	}



	public void getProfileDetail() {
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select * from userpersonal where userid=?;");
			pst.setString(1, accno);
			
			
			rs=pst.executeQuery();
			if(rs.next()) {
		     joiningdate=rs.getString("accno");
			 city=rs.getString("accnm");
			 mobile=rs.getString("acctype");
		     emailid=rs.getString("balance");
			}
			 flag=true;
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}

}
}
