package mybeans;

import java.sql.*;

public class DeleteAccB {
	private String accno;
    public boolean flag=false;
    
	public void setAccno(String accno) {
		this.accno = accno;
	}
	
	
	
	public boolean isFlag() {
		return flag;
	}



	public void onDeletingAcc() {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	try
	{
		DBConnector dbc=new DBConnector();
		con=dbc.getDbconnection();
		pst=con.prepareStatement("select * from accounts where accno=?;");
		pst.setString(1, accno);
		rs=pst.executeQuery();
		if(rs.next()) {
		pst=con.prepareStatement("delete from accounts where accno=?;");
		pst.setString(1,accno);
		pst.executeUpdate();
		pst=con.prepareStatement("delete from users where userid=?;");
		pst.setString(1,accno);
		pst.executeUpdate();
		flag=true;}
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

}
}