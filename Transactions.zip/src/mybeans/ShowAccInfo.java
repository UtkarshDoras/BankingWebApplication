package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ShowAccInfo {
	
	private String accno;
	private String accnm;
	private String acctype;
	private double balance;

	public void setAccno(String accno) {
		this.accno = accno;
		searchAccount();
	}

	public void searchAccount() {
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select * from accounts where accno=?;");
			pst.setString(1, accno);
			
			
			rs=pst.executeQuery();
			if(rs.next()) {
		     accno=rs.getString("accno");
			accnm=rs.getString("accnm");
			acctype=rs.getString("acctype");
		balance=Double.parseDouble(rs.getString("balance"));
			}
			
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

	public String getAccno() {
		return accno;
	}

	public String getAccnm() {
		return accnm;
	}

	public String getAcctype() {
		return acctype;
	}

	public double getBalance() {
		return balance;
	}
	

}
