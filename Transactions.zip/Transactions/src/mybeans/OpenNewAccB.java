package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class OpenNewAccB {
	private String accno;
	private String accnm;
	private String acctype;
	private String date;
	private double balance;
	private boolean insertstatus=false;
	
	public void onOpeningAcc() {
		accno="0";
		accnm="";
		acctype="";
		balance=0.0;
		
	}
	public boolean isInsertstatus() {
		return insertstatus;
	}
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public String getAccnm() {
		return accnm;
	}
	public void setAccnm(String accnm) {
		this.accnm = accnm;
	}
	public String getAcctype() {
		return acctype;
	}
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
		insertAccount();
	}
	
	private void insertAccount() {
		Connection con;
		PreparedStatement pst;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("insert into accounts values(?,?,?,?,default);");
			pst.setString(1, accno);
			pst.setString(2, accnm);
			pst.setString(3, acctype);
			pst.setDouble(4, balance);
			
			
			pst.executeUpdate();
			insertstatus=true;
			con.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
