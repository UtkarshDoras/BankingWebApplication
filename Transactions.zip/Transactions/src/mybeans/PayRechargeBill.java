package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PayRechargeBill {
	
	private String mobno,accno;
	private double amt;
	public boolean flag=false,paymentstatus=false; 
	
	
	public void setAccno(String accno) {
		this.accno = accno;
	}
	
	public void setAmt(double amt) {
		this.amt = amt;
	}

	
	
	public void onRecharging() {
		PreparedStatement pst;
		Connection con;
		ResultSet rs;
		try {
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
	
	pst=con.prepareStatement("select * from userpersonal where mobile=?;");
	pst.setString(1, mobno);
	
	
	rs=pst.executeQuery();
	if(rs.next()) {
		flag=true;
	}
	
	if(flag) {
		
		pst=con.prepareStatement("update accounts set balance=balance+? where accno=?;");
		pst.setDouble(1, amt);
		pst.setString(2, accno);
	    
		pst.executeUpdate();
		paymentstatus=true;
		
		con.close();
		
	}
	}
		catch(Exception e) {
			System.out.println(e);
		}
}
}
