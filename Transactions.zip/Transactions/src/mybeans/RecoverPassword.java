package mybeans;

import java.sql.*;

public class RecoverPassword {
	
	
	public String id,sq,an,mo,nps;
	public boolean flag=false;
	

	
	
	public void recoverPassword() {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	try
	{

		DBConnector dbc=new DBConnector();
		con=dbc.getDbconnection();
		pst=con.prepareStatement("select * from userpersonal where userid=? and secques=? and answer=?;");
		pst.setString(1,id);
		pst.setString(2,sq);
		pst.setString(3,an);
		rs=pst.executeQuery();
		if(rs.next())
		{
			mo=rs.getString("mobile");
			nps=id.substring(1,4)+"$"+mo.substring(3, 8);
			
			pst=con.prepareStatement("update users set pswd=? where userid=?;");
			pst.setString(1,nps);
			pst.setString(2,id);
			pst.executeUpdate();
			flag=true;
		}
		
		con.close();
	}
	catch(Exception e)
	{	
		System.out.println(e);
	}
	}




	public String getNps() {
		return nps;
	}




	public boolean isFlag() {
		return flag;
	}




	public void setId(String id) {
		this.id = id;
	}




	public void setSq(String sq) {
		this.sq = sq;
	}




	public void setAn(String an) {
		this.an = an;
	}

}
