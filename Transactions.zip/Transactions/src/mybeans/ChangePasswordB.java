package mybeans;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ChangePasswordB {
	private String id,curps,newps,conps;
	public boolean cnt=false;
	
	public void setId(String id) {
		this.id = id;
	}
	public void setCurps(String curps) {
		this.curps = curps;
	}
	public void setNewps(String newps) {
		this.newps = newps;
	}
	public void setConps(String conps) {
		this.conps = conps;
	}
	
	public boolean isCnt() {
		return cnt;
	}
	
	public void onChanging() {
		Connection con;
		PreparedStatement pst;
	if(newps.equals(conps))
	{
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("update users set pswd=? where userid=? and pswd=?;");
			pst.setString(1, newps);
			pst.setString(2,id);
			pst.setString(3,curps);
			int cnt1=pst.executeUpdate();
			if(cnt1>=0)
				cnt=true;
			
			
			
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

}


