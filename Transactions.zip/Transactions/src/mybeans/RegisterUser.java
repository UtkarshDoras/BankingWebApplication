package mybeans;

import java.sql.*;

public class RegisterUser {
	private String id,ps,nm,gn,ct,mo,em,sq,an;
	int ag;
	private boolean registerstatus=false;
	
	
	
	
	public void setId(String id) {
		this.id = id;
	}




	public void setPs(String ps) {
		this.ps = ps;
	}




	public void setNm(String nm) {
		this.nm = nm;
	}




	public void setGn(String gn) {
		this.gn = gn;
	}




	public void setCt(String ct) {
		this.ct = ct;
	}




	public void setMo(String mo) {
		this.mo = mo;
	}




	public void setEm(String em) {
		this.em = em;
	}




	public void setSq(String sq) {
		this.sq = sq;
	}




	public void setAn(String an) {
		this.an = an;
	}




	public void setAg(int ag) {
		this.ag = ag;
	}


    public boolean isRegisterstatus() {
		return registerstatus;
	}




	public void registerUser() {
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select * from accounts where accno=?;");
			pst.setString(1, id);
			rs=pst.executeQuery();
			if(rs.next()) {
			pst=con.prepareStatement("insert into users values(?,?,?,default,default);");
			pst.setString(1,id);
			pst.setString(2,ps);
			pst.setString(3,nm);
			pst.executeUpdate();
			
			pst=con.prepareStatement("insert into userpersonal values(?,now(),?,?,?,?,?,?,?);");
			pst.setString(1, id);
			pst.setInt(2, ag);
			pst.setString(3, gn);
			pst.setString(4, ct);
			pst.setString(5, mo);
			pst.setString(6, em);
			pst.setString(7, sq);
			pst.setString(8, an);
			pst.executeUpdate();
			registerstatus=true;
			con.close();
		}
			else {
				registerstatus=false;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
}
}