package myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybeans.ChangePasswordB;

import java.sql.*;

/**
 * Servlet implementation class ChangePasswordS
 */
@WebServlet("/ChangePasswordS")
public class ChangePasswordS extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePasswordS() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		
		String id,curps,newps,conps;
		
		id=request.getParameter("uid");
		curps=request.getParameter("curps");
		newps=request.getParameter("newps");
		conps=request.getParameter("conps");
		
		ChangePasswordB obj=new ChangePasswordB();
		obj.setId(id);
		obj.setCurps(curps);
		obj.setNewps(newps);
		obj.setConps(conps);
		obj.onChanging();
		
		if(obj.isCnt())
		{
			out.println(" <h2 style=\"color:green\" > Password Changed</h2> </br>");
			
			out.println("<a href='customer.jsp'>Home</a>");
			
			}
		else
			out.println(" <h2 style=\"color:green\" >Userid/Current Password incorrect</h2> ");
		
		
		
	}

}
