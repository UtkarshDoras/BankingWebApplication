package myentities;

public class Account {
	
	private String accno;
	private String accnm;
	private String acctype;
	private double balance;
	
	public Account() {
		accno="";
		accnm="";
		acctype="";
		balance=0.0;
		
		
	}

	public String getAccno()
	{
		return accno;
		}
	}
